var express = require('express')
var app = express()
const redis = require('redis');


var senhaVigente

app.use(express.static('public'))
app.set('view engine', 'ejs')
app.set('views', './views')

// Cliente redis
const cli = redis.createClient({
    password: 'afNdK8SXBJuk3oTdoaypZumFHgjBFJgc',
    socket: {
        host: 'redis-10374.c267.us-east-1-4.ec2.cloud.redislabs.com',
        port: 10374
    }
});


app.get("/", async (req, res) => {
    let line = await cli.lRange('fila', 0, -1)
    res.render('index', { senhaVigente: senhaVigente, line: line });
})

app.get("/proximo", async (req, res) => {
    senhaVigente = await cli.lPop('fila')
    res.render('proximo', {senhaVigente:senhaVigente});
})

app.get("/retirar", async (req, res) => {
    let ultimaSenha = await cli.lIndex('ListaSenha', -1)
    let novaSenha = parseInt(ultimaSenha) + 1
    await cli.rPush('ListaSenha', novaSenha.toString())
    await cli.rPush('fila', novaSenha.toString())
    res.render('retirarsenha', {senhaVigente:novaSenha});
});

async function start() {
    await cli.connect()
    console.log('Conectado ao redis')
    app.listen(8000, async () => {
        console.log('Servidor iniciado porta 8000')
        await cli.del('fila')
        await cli.del('ListaSenha')
        await cli.rPush('ListaSenha', ['0'])
        senhaVigente = await cli.lIndex('ListaSenha', 0)
    });
}
cli.on('connect', function (err) {
    if (err) {
      console.log('Could not establish a connection with Redis. ' + err);
    } else {
      console.log('Connected to Redis successfully!');
    }
  });


start()


